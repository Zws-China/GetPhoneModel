//
//  ViewController.h
//  GetIPhoneType
//
//  Created by 李金帅 on 16/2/16.
//  Copyright © 2016年 Jin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

